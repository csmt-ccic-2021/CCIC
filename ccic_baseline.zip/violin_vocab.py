# from typing import Tuple, Union
from warnings import warn

state_index = 0
violin_state_dict = {}  # key: a quadruple of four pitches on the four strings, value: index
index_to_violin_state = []  # revered lookup

vocab2int = {}  # pitch set (iterable) -> int
int2vocab = []  # int -> pitch tuple

special_tokens = ['BOP', 'EOP', 'BAR', 'PAD', 'OOV']
special_indices = []

window_size = 6
starting_pitches = list(reversed([55, 62, 69, 76]))  # reversed so that lower pitch come first in dfs
num_strings = 4

dfs_current_pitches = [None] * num_strings


# dfs for one window from the first string
def dfs(string_index, max_fret):
    global state_index
    if string_index == num_strings:  # all the strings are selected
        state = tuple(dfs_current_pitches)
        if state not in violin_state_dict:
            violin_state_dict[state] = state_index
            index_to_violin_state.append(state)
            # print(state)
            state_index += 1

            pitch_set = tuple([x for x in dfs_current_pitches if x is not None])  # () for empty set
            pitch_set = tuple(sorted(list(set(pitch_set))))  # ordered tuple
            if pitch_set not in vocab2int:
                int2vocab.append(pitch_set)
                vocab2int[pitch_set] = len(vocab2int.keys())
    else:
        for offset in range(-window_size - 1, 1):

            if offset == -window_size - 1:  # special case 1: no note
                dfs_current_pitches[string_index] = None
            elif offset == -window_size:  # special case 2: open string
                dfs_current_pitches[string_index] = starting_pitches[string_index]
            else:  # offset to max_fret
                pitch = starting_pitches[string_index] + max_fret
                pitch += offset
                if pitch < starting_pitches[string_index]:
                    continue
                dfs_current_pitches[string_index] = pitch
            dfs(string_index + 1, max_fret)


def pitch_set_to_int(itr) -> int:
    try:
        s = tuple(sorted(list(set(tuple(itr)))))
        return vocab2int[s]
    except TypeError as err:
        print(err)
        warn(f'The input {itr} should be iterable, not an element.')

    except KeyError as err:
        print(f'Key (pitch set) {err} is treated as <OOV> (Out Of Vocabulary)')
        return vocab2int['OOV']


def build_vocab_dict():
    # slide the window on the fretboard
    for fret in range(18):
        dfs(0, fret)

    # special tokens
    for x in special_tokens:
        int2vocab.append(x)
        vocab2int[x] = len(int2vocab) - 1
        special_indices.append(len(int2vocab) - 1)

    print(f'vocab size: {len(vocab2int.keys())}')


build_vocab_dict()

if __name__ == '__main__':
    # print(pitch_set_to_int([74, 88, 80]))
    print(int2vocab[1374])