import os

import numpy as np
import torch

from torch.utils.data import DataLoader, Dataset

from token_utils import ViolinPiece, write_tokens
from violin_vocab import vocab2int


class ViolinPieceDataset(Dataset):
    """
    :param train: bool value, load train dataset if True else test dataset
    """

    def __init__(self, train=False, oov_threshold=0.03):
        super(ViolinPieceDataset, self).__init__()
        self.train = train
        if self.train:
            print(
                os.listdir('.')
            )
            self.tokens = np.load('./ds_tokens_augmented.npy')
            self.tempos = np.load('./ds_tempos_augmented.npy')
        else:
            self.tokens = np.load('./ds_tokens_test.npy')
            self.tempos = np.load('./ds_tempos_test.npy')

        self.filter_oov(oov_threshold)

    def filter_oov(self, threshold: float = 0.03) -> None:
        size = len(self.tokens)
        oov_ratio = np.mean(np.equal(self.tokens, vocab2int['OOV']), axis=1)
        idx = np.less_equal(oov_ratio, threshold)
        self.tokens = self.tokens[idx]
        self.tempos = self.tempos[idx]
        print(f'Phrases with more than {int(threshold * 100)}% '
              f'of OOVs are removed. {size} -> {self.tokens.shape[0]}')

        # pct = np.arange(0, 100)
        # plt.plot((np.percentile(oov_ratio, pct)))
        # plt.show()

    def __getitem__(self, idx):
        return self.tokens[idx, :], self.tempos[idx]

    def __len__(self):
        return self.tokens.shape[0]


def test_dataset():
    print('Testing dataset')
    bs = 2
    train_dataloader = DataLoader(ViolinPieceDataset(True), batch_size=bs, shuffle=True)
    for i in range(len(train_dataloader)):
        tokens, tempo = next(iter(train_dataloader))
        print(torch.nonzero(torch.eq(tokens, vocab2int['BAR']))[:, 1].T.reshape(bs, -1))
        # write_tokens(tokens[0].tolist(), f'test_2_output_{i}', float(tempo[0]))
        # print(tokens, tempo)


if __name__ == '__main__':
    train_dataloader = DataLoader(ViolinPieceDataset(True), batch_size=1, shuffle=True)
