import math
import os
from typing import *

import torch
import torch.nn as nn
from torch import Tensor
from torch.nn import TransformerEncoder, TransformerEncoderLayer, TransformerDecoder, TransformerDecoderLayer
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from token_utils import vocab2int, default_resolution, default_time_signature, read_midi_file, ViolinPiece
from violin_piece_dataset import ViolinPieceDataset

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')


class PositionalEncoding(nn.Module):
    def __init__(
        self,
        embed_dim: int,
        dropout: float = 0.1,
        max_len: int = 50000
    ):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(dropout)

        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, embed_dim, 2) * (-math.log(10000.0) / embed_dim))
        pe = torch.zeros(max_len, 1, embed_dim)
        pe[:, 0, 0::2] = torch.sin(position * div_term)
        pe[:, 0, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x: Tensor) -> Tensor:
        x += self.pe[:x.size(0)]
        return self.dropout(x)


class ViolinPhraseTransformer(nn.Module):
    def __init__(
        self,
        vocab_size: int,
        embed_dim: int,
        feed_forward_dim: int,
        num_heads: int,
        num_encoder_decoder_layers: int,
        dropout: float = 0.1,
    ):
        super(ViolinPhraseTransformer, self).__init__()
        self.model_type = 'Transformer'
        self.pe = PositionalEncoding(embed_dim, dropout)
        self.embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=embed_dim
        )
        self.tempo_projection = nn.Linear(1, embed_dim)
        self.embed_dim = embed_dim
        encoder_layers = TransformerEncoderLayer(embed_dim, num_heads, feed_forward_dim)
        decoder_layers = TransformerDecoderLayer(embed_dim, num_heads, feed_forward_dim)
        self.transformer_encoder = TransformerEncoder(encoder_layers, num_encoder_decoder_layers)
        self.transformer_decoder = TransformerDecoder(decoder_layers, num_encoder_decoder_layers)
        self.out = nn.Linear(
            in_features=embed_dim,
            out_features=vocab_size
        )

        self.init_weights()

    def init_weights(self) -> None:
        init_range = 0.1
        self.embedding.weight.data.uniform_(-init_range, init_range)
        self.out.bias.data.zero_()
        self.out.weight.data.uniform_(-init_range, init_range)

    def forward(
        self,
        src: Tensor,
        src_mask: Optional[Tensor],
        tgt: Tensor,
        tgt_mask: Optional[Tensor],
        tempo: Tensor
    ) -> Tensor:
        """
        :param src: (s, n) given music phrase, sequence of <BOP>...<BAR>...<EOP>
        :param src_mask: (s, s), optional.
        :param tgt: (t, n) target music phrase.
        :param tgt_mask: (t, t), optional.
        :param tempo: (n,)
        :return: logits_pitch: (s, n, v_s), tempo_pred: (s, n)
        """
        src_emb = self.embedding(src) * math.sqrt(self.embed_dim)  # (s, n, d)
        tgt_emb = self.embedding(tgt) * math.sqrt(self.embed_dim)
        tempo_vec = self.tempo_projection(tempo.unsqueeze(1)).unsqueeze(0)  # (1, n, d)
        tempo_vec = nn.Tanh()(tempo_vec)  # * math.sqrt(self.embed_dim)

        src_tensor = self.pe(src_emb + tempo_vec)  # (s, n, d)
        tgt_tensor = self.pe(tgt_emb + tempo_vec)
        enc_out = self.transformer_encoder.forward(src_tensor, src_mask,
                                                   src_key_padding_mask=get_padding_mask(src).to(device))
        dec_out = self.transformer_decoder.forward(tgt_tensor, enc_out, tgt_mask=tgt_mask,
                                                   tgt_key_padding_mask=get_padding_mask(tgt).to(device))  # (s, n, d)
        logits_pitch = self.out(dec_out)

        return logits_pitch


def get_padding_mask(x: Tensor) -> Tensor:
    """
    Create padding mask from (_, N) to (N, _)
    :param x: (_, N)
    :return: (N, _)
    """
    return torch.eq(x.transpose(1, 0), vocab2int['PAD'])


def get_subsequent_mask(size: int) -> Tensor:
    return torch.triu(torch.ones(size, size) * float('-inf'), diagonal=1)


# Hyper params
# num_heads = 8
# vocab_size = len(vocab2int)
# embed_dim = 1024
# feed_forward_dim = 2048
# num_encoder_decoder_layers = 2

num_heads = 8
vocab_size = len(vocab2int)
embed_dim = 1024
feed_forward_dim = 2048
num_encoder_decoder_layers = 2

num_epochs = 10000
batch_size = 60

# Dataset configuration
train_ds = ViolinPieceDataset(train=True)
test_ds = ViolinPieceDataset(train=False)

train_dataloader = DataLoader(
    train_ds,
    batch_size=batch_size,
    shuffle=True
)

validation_dataloader = DataLoader(
    test_ds,
    batch_size=batch_size // 2,
    shuffle=True
)

# Checkpoint Options
new_model = True
model_base_name = f'baseline_generator_tempo_emb_{num_heads}head_' \
                  f'd{embed_dim}_' \
                  f'h{feed_forward_dim}_' \
                  f'{num_encoder_decoder_layers}l_' \
                  f'large_learning_rate'

model_dir = f'./models/{model_base_name}'
os.makedirs(model_dir, exist_ok=True)
checkpoint_prefix = f'{model_dir}/checkpoint'

current_epoch = 0
global_steps = 0

# Model Initialization
generator = ViolinPhraseTransformer(
    num_heads=num_heads,
    vocab_size=vocab_size,
    embed_dim=embed_dim,
    feed_forward_dim=feed_forward_dim,
    num_encoder_decoder_layers=num_encoder_decoder_layers,
)
current_model = generator

# Optimizer
lr = 0.006
optimizer = torch.optim.SGD(current_model.parameters(), lr=lr)


def load_checkpoint(
    filename: str = None,
    load_latest: bool = True
) -> dict:
    checkpoint = ''

    if filename is not None and os.path.exists(filename):
        print(f'Specified checkpoint: {filename}')
        checkpoint = filename
    elif load_latest:
        # Find latest available checkpoint
        print(f'in dir: {os.listdir(model_dir)}')
        available_checkpoints = list(filter(
            lambda s: s.endswith('.pth'),
            os.listdir(model_dir)
        ))
        available_checkpoints = [model_dir + '/' + s for s in available_checkpoints]
        if len(available_checkpoints) > 0:
            available_checkpoints.sort(key=os.path.getmtime)
            latest = available_checkpoints[-1]
            checkpoint = latest
            print(f'Found latest checkpoint: {checkpoint}')
    else:
        raise Exception('No available checkpoint.')

    if checkpoint != '':
        return torch.load(checkpoint)
    else:
        raise Exception(f'Failed to load checkpoint "{checkpoint}".')


def save_checkpoint(
    filename: str,
):
    torch.save({
        "optimizer": optimizer.state_dict(),
        "model": model.state_dict(),
        "global_steps": global_steps,
        "epochs": current_epoch
    }, filename)


def train(
    model: ViolinPhraseTransformer,
    dataset: DataLoader = train_dataloader,
    num_epochs: int = num_epochs,
    lr: float = lr,
    new_model: bool = new_model,
    save_model_every_n_epochs=1,
    predict_every_n_epochs=10,
    device=device,
    load_optimizer=True
):
    # Load model
    global optimizer
    global current_epoch, global_steps

    if not new_model:
        try:
            cp = load_checkpoint()
            model.load_state_dict(cp['model'])
            if load_optimizer:
                optimizer.load_state_dict(cp['optimizer'])
            current_epoch = cp['epochs']
            global_steps = cp['global_steps']
        except Exception as e:
            answer = input(f'Failed to load previous models because "{e}". Use the model\'s current state? [y/n]')
            if answer.startswith('Y') or answer.startswith('y') or answer == '\n':
                pass
            else:
                print('Aborted.')
                return

    model.train()
    optimizer.param_groups[0]['lr'] = lr
    train_writer = SummaryWriter(f'{model_dir}/logs/train', flush_secs=3)
    validation_writer = SummaryWriter(f'{model_dir}/logs/validation', flush_secs=3)

    epoch_0 = current_epoch
    if global_steps == 0:
        epoch_0 = 1

    for current_epoch in range(epoch_0, epoch_0 + num_epochs):
        print(f'Epoch {current_epoch} begins.')
        num_batches = int(len(dataset))
        epoch_loss = 0

        for _ in range(10):
            torch.cuda.empty_cache()

        batches = tqdm(enumerate(dataset), total=num_batches)
        for batch, (seq, tempo) in batches:
            x = seq.long().to(device)  # (n, s)
            tempo = tempo.to(device)  # (n,)

            begin_bar = x[:, :(1 + default_time_signature * default_resolution)]  # (n, s)
            end_bar = x[:, (-1 - default_time_signature * default_resolution):]
            y_input = x[:, :-1]
            y_true = x[:, 1:]

            # Transform
            bar_lines = torch.ones(begin_bar.size(0), dtype=torch.long).unsqueeze(1).to(device) * vocab2int[
                'BAR']  # (n, 1)
            src = torch.cat([begin_bar, bar_lines, end_bar], dim=-1).transpose(1, 0)  # (s, n)
            tgt = y_input.transpose(1, 0)  # (s_tgt, n)
            tgt_mask = get_subsequent_mask(tgt.size(0)).to(device)

            logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (s_tgt, n, v_s)

            CE = nn.CrossEntropyLoss(ignore_index=vocab2int["PAD"]).to(device)
            pitch_loss = CE(logits_pitch.transpose(1, 0).reshape(-1, vocab_size), y_true.reshape(-1))
            batch_loss = pitch_loss

            # Update
            optimizer.zero_grad()
            batch_loss.backward()
            optimizer.step()

            # Verbose & Log
            global_steps += 1
            epoch_loss += batch_loss.item()
            batches.set_description(f'Batch Loss: Avg {epoch_loss / (batch + 1) :.4f} | '
                                    f'Cur {batch_loss.item() :.4f}')
            train_writer.add_scalar('Loss/Batch', batch_loss.item(), global_step=global_steps)
            train_writer.add_scalar('Loss/Batch_Pitch', pitch_loss.item(), global_step=global_steps)

        epoch_loss /= num_batches
        # Checkpoint Saving
        if (current_epoch - epoch_0) % save_model_every_n_epochs == 0:
            print(f'Saving model: epoch {current_epoch - epoch_0}')
            save_checkpoint(f'{model_dir}/{checkpoint_prefix}.pth')

        # Validate
        validation_loss = validate(model, validation_dataloader)
        print(f'Validation Loss: {validation_loss:.4f}')

        # Log
        train_writer.add_scalar('Loss/Epoch', epoch_loss, global_step=global_steps)
        validation_writer.add_scalar('Loss/Epoch', validation_loss, global_step=global_steps)

        # Predict
        if (current_epoch - epoch_0) % predict_every_n_epochs == 0:
            batch_generate(model, './generator_input', 'generator_output')


def validate(
    model: ViolinPhraseTransformer,
    validation_dataset: DataLoader
):
    model.eval()
    loss = 0
    print('Validation starts.')
    CE = nn.CrossEntropyLoss(ignore_index=vocab2int["PAD"]).to(device)
    for batch, (seq, tempo) in tqdm(enumerate(validation_dataset), total=len(validation_dataset)):
        x = seq.long().to(device)  # (n, s)
        tempo = tempo.to(device)  # (n,)

        begin_bar = x[:, :(1 + default_time_signature * default_resolution)]  # (n, s)
        end_bar = x[:, (-1 - default_time_signature * default_resolution):]
        y_input = x[:, :-1]
        y_true = x[:, 1:]

        # Transform
        bar_lines = torch.ones(begin_bar.size(0), dtype=torch.long).unsqueeze(1).to(device) * vocab2int['BAR']  # (n, 1)
        src = torch.cat([begin_bar, bar_lines, end_bar], dim=-1).transpose(1, 0)  # (s, n)
        tgt = y_input.transpose(1, 0)  # (s_tgt, n)
        tgt_mask = get_subsequent_mask(tgt.size(0)).to(device)

        logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (s_tgt, n, v_s)

        pitch_loss = CE(logits_pitch.transpose(1, 0).reshape(-1, vocab_size), y_true.reshape(-1))
        loss += pitch_loss.item()
    loss /= len(validation_dataset)
    model.train()
    return loss


def predict(
    model: ViolinPhraseTransformer,
    begin=[8] * default_resolution,
    end=[8] * default_resolution,
    bars=8,
    tempo=120.0,
    write_to_file=True
) -> Tuple[float, List[int]]:
    model.eval()
    num_tokens = default_resolution * default_time_signature
    begin_pad = []
    end_pad = []
    BOP = vocab2int['BOP']
    EOP = vocab2int['EOP']
    PAD = vocab2int['PAD']
    BAR = vocab2int['BAR']
    if len(begin) < num_tokens:
        begin_pad = [PAD] * (num_tokens - len(begin))
    if len(end) < num_tokens:
        end_pad = [PAD] * (num_tokens - len(end))
    src_seq = [BOP] + begin + begin_pad + [BAR] + end + end_pad + [EOP]
    src = torch.tensor(src_seq, dtype=torch.long).to(device).unsqueeze(1)  # (s, 1)

    max_len = (bars - 1) * default_resolution * default_time_signature + bars
    tgt = torch.tensor([BOP] + begin + begin_pad + [BAR], dtype=torch.long).unsqueeze(1).to(device)  # (1, 1)
    tempo = torch.FloatTensor([tempo]).to(device)  # (1,)
    while tgt.size(0) < max_len:
        logits_pitch = model.forward(src, None, tgt, None, tempo)
        y_pred = torch.argmax(torch.softmax(logits_pitch[-1], dim=-1))
        tgt = torch.cat([tgt, y_pred.reshape(1, 1)], dim=0)
    result = float(tempo), tgt.squeeze().tolist() + end + end_pad + [EOP]

    # debug output
    if write_to_file:
        with open('generator_output.txt', 'a+') as f:
            f.write(f'Epoch {current_epoch} input: {src_seq}\n'
                    f'output: {int(result[0])} BPM, {result[1]}\r\n\n')
    # debug
    return result


def generate_phrase_from_two_bar_midi_file(
    model: ViolinPhraseTransformer,
    filename='./generator_input/phrase_001.mid',
    output_filename='output.mid',
    output_dir='./generator_output/',
    num_bars=8,
    quiet=True
):
    midi_info = read_midi_file(filename)
    vp = ViolinPiece(*midi_info.values())
    vp.tokenize()
    half_len = len(vp.tokens) // 2
    tokens_begin = vp.tokens[:half_len]
    tokens_end = vp.tokens[half_len:]
    assert len(tokens_begin) == vp.resolution * vp.time_signature, (
        len(tokens_begin), vp.resolution * vp.time_signature)
    assert len(tokens_end) == vp.resolution * vp.time_signature, (len(tokens_end), vp.resolution * vp.time_signature)
    tempo, tokens = predict(model, tokens_begin, tokens_end, bars=num_bars)
    vp.tokens = tokens
    vp.tempo = tempo
    if not quiet:
        print(f'Generated from {filename}. Tempo: {tempo}, tokens: {tokens}')
    os.makedirs(output_dir, exist_ok=True)
    vp.write_to_midi(basename=output_filename, path=output_dir)


def batch_generate(model, input_dir, output_dir):
    midi_files = list(filter(
        lambda filename: filename.endswith('.mid') or filename.endswith('midi'),
        os.listdir(input_dir)
    ))
    for i, filename in enumerate(midi_files):
        print(f'Generating phrase {i + 1}/{len(midi_files)}')
        generate_phrase_from_two_bar_midi_file(
            model,
            input_dir + '/' + filename,
            filename,
            output_dir
        )


if __name__ == '__main__':
    model = current_model.to(device)
    cp = load_checkpoint()
    model.load_state_dict(cp['model'])
    batch_generate(
        model,
        input_dir='./generator_input',
        output_dir='./generator_output'
    )
    # train(model, new_model=False, save_model_every_n_epochs=50, predict_every_n_epochs=5)
