from dataclasses import dataclass
import numpy as np
import os

from violin_vocab import pitch_set_to_int, int2vocab, vocab2int, special_indices
import pypianoroll as ppr  # Comment this line if not available

max_frames = 1000
default_resolution = 12
default_tempo = 120.0
violin_instrument_id = 40
default_time_signature = 4
default_velocity = 100


@dataclass
class ViolinPiece:
    pianoroll: np.ndarray = np.zeros([max_frames, 128])
    tempo: float = default_tempo
    time_signature: int = default_time_signature
    resolution: int = default_resolution

    def tokenize(self):
        # TODO: BOP, EOP, BAR, PAD
        self.tokens = []
        pr = self.pianoroll
        for frame in pr:
            indices = np.nonzero(frame)[0].tolist()
            token = pitch_set_to_int(indices)
            self.tokens.append(token)

    def generate_midi_track_from_tokens(self):
        pianoroll = np.zeros([len(self.tokens), 128], dtype=bool)
        steps = 0
        for token in self.tokens:
            if token == vocab2int['OOV']:
                token = 0
            elif token in special_indices:  # Zero-width tokens are skipped.
                continue
            pitch_set = int2vocab[token]
            for pitch in pitch_set:
                if pitch is not None:
                    pianoroll[steps, pitch] = default_velocity
            steps += 1
        track = ppr.track.BinaryTrack('track', violin_instrument_id, False, pianoroll)
        return track

    def write_to_midi(self, basename='violin_pieces_sample_output', path='./'):
        extension = '.mid'
        if not hasattr(self, 'tokens'):
            print('Tokens are not generated, run `tokenize()` first')
        if basename.endswith(extension):
            extension = ''

        track = self.generate_midi_track_from_tokens()
        mt = ppr.Multitrack('from tokens', resolution=default_resolution,  # TODO: note: default for ppr
                            tempo=np.ones(len(self.tokens)) * self.tempo, tracks=[track])
        ppr.write(path + '/' + basename + extension, multitrack=mt)


def read_midi_file(filename) -> dict:
    multitrack = ppr.read(filename)
    multitrack.set_resolution(default_resolution, 'floor')
    # TODO: Down sampling (by setting a lower resolution) will distort some beats! Be aware of the data quality loss.

    # make sure all the tracks have the same length
    multitrack = multitrack.pad_to_same()
    multitrack = multitrack.pad_to_multiple(4)

    # rewrite the original tempo with the average tempo
    tempo = multitrack.tempo.mean()

    # binarize
    threshold = 1
    multitrack.binarize(threshold)

    merged = np.zeros_like(multitrack.tracks[0])
    for track in multitrack.tracks:
        merged = np.bitwise_or(merged, track.pianoroll)

    # print(merged.shape)
    return {
        "pianoroll": merged, "tempo": tempo, "time_signature": default_time_signature,
        # TODO: add support of time signature
        "resolution": default_resolution,  # frames per beat
    }


def build_dataset(
    midi_dir, bars_per_slice=8, pitch_shift_range=4, out_of_vocabulary=vocab2int['OOV'], train_test_split_ratio=0.8,
    random_seed=0
):
    np.random.seed(random_seed)

    filenames = os.listdir(midi_dir)
    tokens = []
    tempos = []

    counter = 0
    for filename in filenames:
        print(filename)
        if filename.endswith('.mid'):
            midi_info = read_midi_file(midi_dir + '/' + filename)
            piece = ViolinPiece(*midi_info.values())
            piece.tokenize()
            tokens.append(piece.tokens)
            tempos.append(piece.tempo)
            counter += 1

    ds_tokens = []
    ds_tempos = []

    # slicing and assemble
    slice_len = bars_per_slice * default_time_signature * default_resolution
    TPB = default_resolution * default_time_signature  # Tokens per bar
    phrase_length = TPB * bars_per_slice + bars_per_slice + 1  # Frames + N-1 bar lines inside + 1 BOP + 1 EOP

    for tks, tempo in zip(tokens, tempos):
        num_beats = len(tks) // default_resolution
        num_bars = num_beats // default_time_signature
        num_slices = num_bars // bars_per_slice

        # Insert BOP and EOP
        BOP = vocab2int['BOP']
        EOP = vocab2int['EOP']
        PAD = vocab2int['PAD']
        BAR = vocab2int['BAR']

        # Slicing
        for i in range(num_slices):
            phrase = tks[i * slice_len: (i + 1) * slice_len]
            phrase = np.insert(phrase, slice(TPB, TPB * bars_per_slice, TPB), BAR).tolist()
            assert len(phrase) == phrase_length - 2, (len(phrase), phrase_length - 2)
            ds_tokens.append([BOP] + phrase + [EOP])
            ds_tempos.append(tempo)

        # reminder
        reminder = len(tokens) - num_slices * slice_len
        if reminder > 0:
            lst = tks[-reminder:]
            while lst[-1] != 0:
                lst.pop()
                if lst == []:
                    break
            if lst == []:
                continue
            lst += [PAD] * (TPB * bars_per_slice - len(lst))
            phrase = np.insert(lst, slice(TPB, TPB * bars_per_slice, TPB), BAR).tolist()
            phrase = [BOP] + phrase + [EOP]
            assert len(phrase) == phrase_length

            ds_tokens.append(phrase)
            ds_tempos.append(tempo)

    ds_tokens = np.array(ds_tokens, dtype=np.int32)
    ds_tempos = np.array(ds_tempos, dtype=np.float32)

    idx = np.arange(ds_tokens.shape[0])
    np.random.seed(0)
    np.random.shuffle(idx)
    num_examples = ds_tokens.shape[0]
    num_train = int(num_examples * train_test_split_ratio)
    train_idx, test_idx = idx[:num_train], idx[num_train:]

    tokens_train = ds_tokens[train_idx, :]
    tokens_test = ds_tokens[test_idx, :]
    tempos_train = ds_tempos[train_idx]
    tempos_test = ds_tempos[test_idx]

    # Data augmentation for train set.

    def apply_pitch_offset_to_token(tk, offset) -> int:
        if tk in special_indices or tk == 0:
            return tk

        pitches = int2vocab[tk]
        pitches = (x + offset for x in pitches)
        PAD = vocab2int['PAD']
        result = pitch_set_to_int(pitches)
        return result if result != PAD else out_of_vocabulary

    apply_offset = np.vectorize(apply_pitch_offset_to_token)

    variations = 2 * pitch_shift_range + 1
    tokens_train_augmented = np.zeros([num_train * variations, phrase_length], int)
    tempos_train_augmented = np.repeat(tempos_train, variations)
    for i, phrase in enumerate(tokens_train):
        for shift in range(-pitch_shift_range, pitch_shift_range + 1):
            j = shift + pitch_shift_range
            index = i * variations + j
            tokens_train_augmented[index] = apply_offset(phrase, shift)

    print(f'{counter} midi files processed. Dataset shape: tokens: {ds_tokens.shape}, tempos: {ds_tempos.shape}')
    np.save('ds_tokens_augmented.npy', tokens_train_augmented)
    np.save('ds_tempos_augmented.npy', tempos_train_augmented)
    np.save('ds_tokens_test.npy', tokens_test)
    np.save('ds_tempos_test.npy', tempos_test)


def test_MIDI_rebuild():
    pianoroll_obj = read_midi_file('./bach/Violin_list/vp1-2ald.mid')
    piece = ViolinPiece(*pianoroll_obj.values())
    piece.tokenize()
    piece.write_to_midi()


def write_tokens(tokens, filename, tempo=120.0):
    print(f'num_tokens: {len(tokens)}')
    vp = ViolinPiece(tempo=tempo)
    vp.tokens = tokens
    vp.write_to_midi(filename)


def test_write_tokens():
    name = 'test.mid'
    write_tokens(
        [18739, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 305,
         305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305,
         305, 18741, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26,
         1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302, 1302,
         1302, 1302, 1302, 1302, 1302, 1302, 18741, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260,
         260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260,
         260, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18741, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296,
         1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296, 1296,
         1296, 1296, 1296, 1296, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 18741, 1341, 1341, 1341, 1341,
         1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1341, 1315, 1315,
         1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315,
         1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 1315, 18741, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252,
         8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252,
         8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252, 8252,
         8252, 8252, 8252, 18741, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
         6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 18741, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6,
         6, 6, 6, 6, 6, 6, 6, 6, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633, 633,
         633, 633, 633, 633, 633, 633, 633, 18740]
        , name, tempo=120)
    os.system(f'start {name}')

if __name__ == '__main__':
    pass
    # test_MIDI_rebuild()
    # build_dataset('./bach/Violin_list')
    
