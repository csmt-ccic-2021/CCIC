import math
import os
from typing import *

import torch
import torch.nn as nn
from torch import Tensor
from torch.nn import TransformerEncoder, TransformerEncoderLayer, TransformerDecoder, TransformerDecoderLayer
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from token_utils import vocab2int, default_resolution, default_time_signature, read_midi_file, ViolinPiece
from violin_piece_dataset import ViolinPieceDataset

from generator import ViolinPhraseTransformer, get_subsequent_mask, load_checkpoint, save_checkpoint

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

# Hyper params
# num_heads = 8
# vocab_size = len(vocab2int)
# embed_dim = 1024
# feed_forward_dim = 2048
# num_encoder_decoder_layers = 2

num_heads = 8
vocab_size = len(vocab2int)
embed_dim = 1024
feed_forward_dim = 2048
num_encoder_decoder_layers = 2

num_epochs = 10000
batch_size = 60

# Dataset configuration
train_ds = ViolinPieceDataset(train=True)
test_ds = ViolinPieceDataset(train=False)

train_dataloader = DataLoader(
    train_ds,
    batch_size=batch_size,
    shuffle=True
)

validation_dataloader = DataLoader(
    test_ds,
    batch_size=batch_size // 2,
    shuffle=True
)

# Checkpoint Options
new_model = True
model_base_name = f'baseline_judge_tempo_emb_{num_heads}head_' \
                  f'd{embed_dim}_' \
                  f'h{feed_forward_dim}_' \
                  f'{num_encoder_decoder_layers}l_' \
                  f'large_learning_rate'

model_dir = f'./models/{model_base_name}'
os.makedirs(model_dir, exist_ok=True)
checkpoint_prefix = f'{model_dir}/checkpoint'

current_epoch = 0
global_steps = 0

# Model Initialization
generator = ViolinPhraseTransformer(
    num_heads=num_heads,
    vocab_size=vocab_size,
    embed_dim=embed_dim,
    feed_forward_dim=feed_forward_dim,
    num_encoder_decoder_layers=num_encoder_decoder_layers,
)
current_model = generator

# Optimizer
lr = 0.006
optimizer = torch.optim.SGD(current_model.parameters(), lr=lr)


def train(
    model: ViolinPhraseTransformer,
    dataset: DataLoader = train_dataloader,
    num_epochs: int = num_epochs,
    lr: float = lr,
    new_model: bool = new_model,
    save_model_every_n_epochs=1,
    predict_every_n_epochs=10,
    device=device,
    load_optimizer=True
):
    # Load model
    global optimizer
    global current_epoch, global_steps

    if not new_model:
        try:
            cp = load_checkpoint()
            model.load_state_dict(cp['model'])
            if load_optimizer:
                optimizer.load_state_dict(cp['optimizer'])
            current_epoch = cp['epochs']
            global_steps = cp['global_steps']
        except Exception as e:
            answer = input(f'Failed to load previous models because "{e}". Use the model\'s current state? [y/n]')
            if answer.startswith('Y') or answer.startswith('y') or answer == '\n':
                pass
            else:
                print('Aborted.')
                return

    model.train()
    optimizer.param_groups[0]['lr'] = lr
    train_writer = SummaryWriter(f'{model_dir}/logs/train', flush_secs=3)
    validation_writer = SummaryWriter(f'{model_dir}/logs/validation', flush_secs=3)

    epoch_0 = current_epoch
    if global_steps == 0:
        epoch_0 = 1

    for current_epoch in range(epoch_0, epoch_0 + num_epochs):
        print(f'Epoch {current_epoch} begins.')
        num_batches = int(len(dataset))
        epoch_loss = 0

        for _ in range(10):
            torch.cuda.empty_cache()

        batches = tqdm(enumerate(dataset), total=num_batches)
        for batch, (seq, tempo) in batches:
            x = seq.long().to(device)  # (n, s)
            tempo = tempo.to(device)  # (n,)

            y_input = x[:, :-1]
            y_true = x[:, 1:]

            src = x.transpose(1, 0)  # (s, n)
            tgt = y_input.transpose(1, 0)  # (s_tgt, n)
            tgt_mask = get_subsequent_mask(tgt.size(0)).to(device)

            logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (s_tgt, n, v_s)

            CE = nn.CrossEntropyLoss(ignore_index=vocab2int["PAD"]).to(device)
            pitch_loss = CE(logits_pitch.transpose(1, 0).reshape(-1, vocab_size), y_true.reshape(-1))
            batch_loss = pitch_loss

            # Update
            optimizer.zero_grad()
            batch_loss.backward()
            optimizer.step()

            # Verbose & Log
            global_steps += 1
            epoch_loss += batch_loss.item()
            batches.set_description(f'Batch Loss: Avg {epoch_loss / (batch + 1) :.4f} | '
                                    f'Cur {batch_loss.item() :.4f}')
            train_writer.add_scalar('Loss/Batch', batch_loss.item(), global_step=global_steps)
            train_writer.add_scalar('Loss/Batch_Pitch', pitch_loss.item(), global_step=global_steps)

        epoch_loss /= num_batches
        # Checkpoint Saving
        if (current_epoch - epoch_0) % save_model_every_n_epochs == 0:
            print(f'Saving model: epoch {current_epoch - epoch_0}')
            save_checkpoint(f'{model_dir}/{checkpoint_prefix}.pth')

        # Validate
        validation_loss = validate(model, validation_dataloader)
        print(f'Validation Loss: {validation_loss:.4f}')

        # Log
        train_writer.add_scalar('Loss/Epoch', epoch_loss, global_step=global_steps)
        validation_writer.add_scalar('Loss/Epoch', validation_loss, global_step=global_steps)

        # Predict
        if (current_epoch - epoch_0) % predict_every_n_epochs == 0:
            batch_judge(model, './generator_input', 'generator_output')


def validate(
    model: ViolinPhraseTransformer,
    validation_dataset: DataLoader
):
    model.eval()
    loss = 0
    print('Validation starts.')
    CE = nn.CrossEntropyLoss(ignore_index=vocab2int["PAD"]).to(device)
    for batch, (seq, tempo) in tqdm(enumerate(validation_dataset), total=len(validation_dataset)):
        x = seq.long().to(device)  # (n, s)
        tempo = tempo.to(device)  # (n,)

        y_input = x[:, :-1]
        y_true = x[:, 1:]

        # Transform
        src = x.transpose(1, 0)  # (s, n)
        tgt = y_input.transpose(1, 0)  # (s_tgt, n)
        tgt_mask = get_subsequent_mask(tgt.size(0)).to(device)

        logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (s_tgt, n, v_s)

        pitch_loss = CE(logits_pitch.transpose(1, 0).reshape(-1, vocab_size), y_true.reshape(-1))
        loss += pitch_loss.item()
    loss /= len(validation_dataset)
    model.train()
    return loss


def predict(
    model: ViolinPhraseTransformer,
    phrase: List[int],
    tempo=120.0,
    write_to_file=True
) -> float:
    model.eval()
    assert len(phrase) > default_resolution * default_time_signature * 2
    assert phrase[0] == vocab2int['BOP']
    assert phrase[-1] == vocab2int['EOP']
    begin = phrase[:default_resolution * default_time_signature + 1]
    end = phrase[-default_resolution * default_time_signature - 1:]
    src_seq = begin + [vocab2int['BAR']] + end
    src = torch.tensor(src_seq, dtype=torch.long).to(device).unsqueeze(1)  # (s, 1)

    y = torch.tensor(phrase, dtype=torch.long).unsqueeze(1).to(device)  # (t, 1)
    tgt = y[:-1] # (t - 1, 1)
    tgt_mask = get_subsequent_mask(len(phrase) - 1).to(device)  # (t - 1, t - 1)

    tempo = torch.FloatTensor([tempo]).to(device)  # (1,)
    logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (t - 1, 1, v_s)
    CE = nn.CrossEntropyLoss(ignore_index=vocab2int['PAD']).to(device)
    loss = CE(logits_pitch.squeeze(), y[1:].squeeze())

    hcs = torch.exp(-loss)
    return float(hcs)


def get_hcs_from_midi_file(
    model: ViolinPhraseTransformer,
    filename='./judge_input/phrase_001.mid',
) -> float:
    midi_info = read_midi_file(filename)
    vp = ViolinPiece(*midi_info.values())
    vp.tokenize()
    tokens = vp.tokens

    bar_length = vp.resolution * vp.time_signature
    phrase_length = len(tokens)
    assert phrase_length % bar_length == 0, f'Please pad the length ' \
                                            f'from {phrase_length} to ' \
                                            f'{math.ceil(phrase_length / bar_length)}'
    # Insert special tokens
    num_bars = phrase_length // bar_length
    tokens_padded = []
    for i in range(num_bars):
        tokens_padded += tokens[i * bar_length:(i + 1) * bar_length]
        tokens_padded += [vocab2int['BAR']]
    tokens_padded[-1] = vocab2int['EOP']
    tokens_padded.insert(0, vocab2int['BOP'])

    tokens_begin = tokens_padded[:bar_length]
    tokens_end = tokens_padded[bar_length:]
    hcs = predict(model, tokens_padded, tempo=vp.tempo, write_to_file=False)
    return hcs

def batch_judge(model, input_dir, output_filename):
    midi_files = list(filter(
        lambda filename: filename.endswith('.mid') or filename.endswith('midi'),
        os.listdir(input_dir)
    ))
    with open(output_filename, 'w') as output:
        for i, filename in enumerate(midi_files):
            print(f'Judging phrase {i + 1}/{len(midi_files)}, HCS: ', end='')
            hcs = get_hcs_from_midi_file(model, input_dir + '/' + filename)
            print(f'{hcs: .3f}')
            output.write(f'{hcs:.3f}\r\n')


if __name__ == '__main__':
    model = current_model.to(device)
    
    # Out of convinience, the judge model uses the same parameters from the pretrained `generator` model.
    cp = load_checkpoint('./models/baseline_generator_tempo_emb_8head_d1024_h2048_2l_large_learning_rate/checkpoint.pth')
    model.load_state_dict(cp['model'])
    batch_judge(
        model,
        input_dir='./judge_input',
        output_filename='./judge_output/anonoymous_composer.txt'
    )
    # train(model, new_model=False, save_model_every_n_epochs=50, predict_every_n_epochs=5)
