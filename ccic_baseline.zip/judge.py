import math
import os
from typing import *

import torch
import torch.nn as nn
from torch import Tensor
from torch.nn import TransformerEncoder, TransformerEncoderLayer, TransformerDecoder, TransformerDecoderLayer
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from token_utils import vocab2int, default_resolution, default_time_signature, read_midi_file, ViolinPiece
from violin_piece_dataset import ViolinPieceDataset

from generator import ViolinPhraseTransformer, get_subsequent_mask, load_checkpoint, save_checkpoint

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

# Hyper params

num_heads = 2
vocab_size = len(vocab2int)
embed_dim = 64
feed_forward_dim = 128
num_encoder_decoder_layers = 1


# num_heads = 4
# vocab_size = len(vocab2int)
# embed_dim = 512
# feed_forward_dim = 2048
# num_encoder_decoder_layers = 2

num_epochs = 10000
batch_size = 2

# Dataset configuration
train_ds = ViolinPieceDataset(train=True, oov_threshold=0.03)
test_ds = ViolinPieceDataset(train=False, oov_threshold=0.03)

train_dataloader = DataLoader(
    train_ds,
    batch_size=batch_size,
    shuffle=True
)

validation_dataloader = DataLoader(
    test_ds,
    batch_size=batch_size // 2,
    shuffle=True
)

# Checkpoint Options
new_model = True
model_base_name = f'baseline_judge_tempo_emb_{num_heads}head_' \
                  f'd{embed_dim}_h{feed_forward_dim}_{num_encoder_decoder_layers}l'
work_dir = f'./models/{model_base_name}'
os.makedirs(work_dir, exist_ok=True)
os.chdir(work_dir)
checkpoint_prefix = './checkpoint'

current_epoch = 0
global_steps = 0

# Model Initialization
generator = ViolinPhraseTransformer(
    num_heads=num_heads,
    vocab_size=vocab_size,
    embed_dim=embed_dim,
    feed_forward_dim=feed_forward_dim,
    num_encoder_decoder_layers=num_encoder_decoder_layers,
)
current_model = generator

# Optimizer
lr = 0.01
optimizer = torch.optim.SGD(current_model.parameters(), lr=lr)


def train(
    model: ViolinPhraseTransformer,
    dataset: DataLoader = train_dataloader,
    num_epochs: int = num_epochs,
    lr: float = lr,
    new_model: bool = new_model,
    save_model_every_n_epochs=1,
    predict_every_n_epochs=10,
    device=device,
    load_optimizer=True
):
    # Load model
    global optimizer
    global current_epoch, global_steps

    if not new_model:
        try:
            cp = load_checkpoint()
            model.load_state_dict(cp['model'])
            if load_optimizer:
                optimizer.load_state_dict(cp['optimizer'])
            current_epoch = cp['epochs']
            global_steps = cp['global_steps']
        except Exception as e:
            answer = input(f'Failed to load previous models because "{e}". Use the model\'s current state? [y/n]')
            if answer.startswith('Y') or answer.startswith('y') or answer == '\n':
                pass
            else:
                print('Aborted.')
                return

    model.train()
    optimizer.param_groups[0]['lr'] = lr
    train_writer = SummaryWriter('./logs/train', flush_secs=3)
    validation_writer = SummaryWriter('./logs/validation', flush_secs=3)

    epoch_0 = current_epoch
    if global_steps == 0:
        epoch_0 = 1

    for current_epoch in range(epoch_0, epoch_0 + num_epochs):
        print(f'Epoch {current_epoch} begins.')
        num_batches = int(len(dataset))
        epoch_loss = 0

        for _ in range(10):
            torch.cuda.empty_cache()

        CE = nn.CrossEntropyLoss(ignore_index=vocab2int["PAD"]).to(device)
        batches = tqdm(enumerate(dataset), total=num_batches)
        for batch, (seq, tempo) in batches:
            x = seq.long().to(device)  # (n, s)
            tempo = tempo.to(device)  # (n,)

            y_input = x[:, :-1]
            y_true = x[:, 1:]

            src = x.transpose(1, 0)  # (s, n)
            tgt = y_input.transpose(1, 0)  # (s_tgt, n)
            tgt_mask = get_subsequent_mask(tgt.size(0)).to(device)

            logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (s_tgt, n, v_s)

            pitch_loss = CE(logits_pitch.transpose(1, 0).reshape(-1, vocab_size), y_true.reshape(-1))
            batch_loss = pitch_loss

            # Update
            optimizer.zero_grad()
            batch_loss.backward()
            optimizer.step()

            # Verbose & Log
            global_steps += 1
            epoch_loss += batch_loss.item()
            batches.set_description(f'Batch Loss: Avg {epoch_loss / (batch + 1) :.4f} | '
                                    f'Cur {batch_loss.item() :.4f}')
            train_writer.add_scalar('Loss/Batch', batch_loss.item(), global_step=global_steps)
            train_writer.add_scalar('Loss/Batch_Pitch', pitch_loss.item(), global_step=global_steps)

        epoch_loss /= num_batches
        # Checkpoint Saving
        if (current_epoch - epoch_0) % save_model_every_n_epochs == 0:
            print(f'Saving model: epoch {current_epoch - epoch_0}')
            # save_checkpoint(f'{checkpoint_prefix}_epoch_{current_epoch}.pth')
            save_checkpoint(f'{checkpoint_prefix}.pth')

        # Validate
        validation_loss = validate(model, validation_dataloader)
        print(f'Validation Loss: {validation_loss:.4f}')

        # Log
        train_writer.add_scalar('Loss/Epoch', epoch_loss, global_step=global_steps)
        validation_writer.add_scalar('Loss/Epoch', validation_loss, global_step=global_steps)


def validate(
    model: ViolinPhraseTransformer,
    validation_dataset: DataLoader
):
    model.eval()
    loss = 0
    print('Validation starts.')
    CE = nn.CrossEntropyLoss(ignore_index=vocab2int["PAD"]).to(device)
    for batch, (seq, tempo) in tqdm(enumerate(validation_dataset), total=len(validation_dataset)):
        x = seq.long().to(device)  # (n, s)
        tempo = tempo.to(device)  # (n,)

        y_input = x[:, :-1]
        y_true = x[:, 1:]

        # Transform
        src = x.transpose(1, 0)  # (s, n)
        tgt = y_input.transpose(1, 0)  # (s_tgt, n)
        tgt_mask = get_subsequent_mask(tgt.size(0)).to(device)

        logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)  # (s_tgt, n, v_s)

        pitch_loss = CE(logits_pitch.transpose(1, 0).reshape(-1, vocab_size), y_true.reshape(-1))
        loss += pitch_loss.item()
    loss /= len(validation_dataset)
    model.train()
    return loss


def predict(
    model: ViolinPhraseTransformer,
    phrase: List[int],
    tempo=120.0,
    write_to_file=True
) -> Tuple[float, List[int]]:
    model.eval()
    assert len(phrase) > default_resolution * default_time_signature * 2
    assert phrase[0] == vocab2int['BOP']
    assert phrase[-1] == vocab2int['EOP']
    begin = phrase[:default_resolution * default_time_signature + 1]
    end = phrase[-default_resolution * default_time_signature - 1:]
    src_seq = begin + vocab2int['BAR'] + end
    src = torch.tensor(src_seq, dtype=torch.long).to(device).unsqueeze(1)  # (s, 1)

    tgt = torch.tensor(phrase[:-1], dtype=torch.long).unsqueeze(1).to(device)  # (t - 1, 1)
    tgt_mask = get_subsequent_mask(len(phrase) - 1).to(device)  # (t - 1, t - 1)

    tempo = torch.FloatTensor([tempo]).to(device)  # (1,)
    logits_pitch = model.forward(src, None, tgt, tgt_mask, tempo)
    y_pred = torch.argmax(torch.softmax(logits_pitch, dim=-1))  # [
    CE = nn.CrossEntropyLoss(ignore_index=vocab2int['PAD']).to(device)
    loss = CE(y_pred.squeeze(), tgt[1:])

    hcs = torch.exp(-loss)

    result = tempo, tgt.squeeze().tolist()

    # debug output
    if write_to_file:
        with open('generator_output.txt', 'a+') as f:
            f.write(f'Epoch {current_epoch} input: {src_seq}\n'
                    f'output: {int(result[0])} BPM, {result[1]}\r\n\n')
    # debug
    return result


def generate_phrase_from_two_bar_midi_file(
    model: ViolinPhraseTransformer,
    filename='../../test/song_00.mid',
    output_filename='output',
    output_dir='.'
):
    midi_info = read_midi_file(filename)
    vp = ViolinPiece(*midi_info.values())
    vp.tokenize()
    half_len = len(vp.tokens) // 2
    tokens_begin = vp.tokens[:half_len]
    tokens_end = vp.tokens[half_len:]
    assert len(tokens_begin) == vp.resolution * vp.time_signature, (
        len(tokens_begin), vp.resolution * vp.time_signature)
    assert len(tokens_end) == vp.resolution * vp.time_signature, (len(tokens_end), vp.resolution * vp.time_signature)
    tempo, tokens = predict(model, tokens_begin, tokens_end)
    vp.tokens = tokens
    vp.tempo = tempo
    print(f'Generated from {filename}. Tempo: {tempo}, tokens: {tokens}')
    vp.write_to_midi(basename=output_filename, path=output_dir)


if __name__ == '__main__':
    model = current_model.to(device)
    # generate_phrase_from_two_bar_midi_file(midi_head_end, 'output')
    train(model, new_model=False, save_model_every_n_epochs=10)
